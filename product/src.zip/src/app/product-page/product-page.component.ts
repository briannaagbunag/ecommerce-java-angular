import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product';
import { ProductCategory } from '../model/product-category';
import { ProductService } from '../service/product.service';

@Component({
  selector: 'app-product-page',
  templateUrl: './product-page.component.html',
  styleUrls: ['./product-page.component.css']
})
export class ProductPageComponent {
  loadingStates: { [key: number]: boolean } = {};
  public productsCategory: ProductCategory[] = [];
  errorMessage: string = '';
  selectedProduct: Product | null = null;

  constructor(private productService: ProductService) {}

  cartItems: any[] = [];  

  ngOnInit(): void {
    this.cartItems = this.productService.getProduct();
    };

}



