import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BaseHttpService } from './base-http.service';

@Injectable({
  providedIn: 'root'
})
export class ProductService extends BaseHttpService{

  private cartItems: any[] = [];

  constructor(protected override http: HttpClient) { 
    super(http, '/api/product')
  }

  public addProduct(product: any) {
    return this.cartItems.push(product);
  }

  public getProduct() {
    return this.cartItems;
  }

  public deleteProduct(product: any) {
    const index = this.cartItems.indexOf(product);
    if (index > -1) {
      this.cartItems.splice(index, 1);
    }
  }
  
 }
