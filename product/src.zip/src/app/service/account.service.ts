import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from '../model/customer';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  private isLoggedIn = false;
  private baseUrl = 'http://localhost:8080/api/customers'; // Set base URL for customer endpoints

  constructor(private http: HttpClient) {}

  setLoginStatus(status: boolean) {
    this.isLoggedIn = status;
  }

  getLoginStatus(): boolean {
    return this.isLoggedIn;
  }

  // Sign up a new user
  signUp(customer: Customer): Observable<Customer> {
    return this.http.post<Customer>(this.baseUrl, customer); // POST to sign-up endpoint
  }

  // Login an existing user
  login(credentials: { username: string; password: string }): Observable<any> {
    return this.http.post<any>('http://localhost:8080/api/auth/login', credentials); // POST to login endpoint
  }
}
