import { Component, OnInit } from '@angular/core';
import { ProductCategory } from '../model/product-category';
import { ProductService } from '../service/product.service';
import { AccountService } from '../service/account.service';

@Component({
  selector: 'app-product-category',
  templateUrl: './product-category.component.html',
  styleUrls: ['./product-category.component.css'],
})
export class ProductCategoryComponent implements OnInit {

  public productsCategory: ProductCategory[]  = [];

  constructor(
    private accountService: AccountService,
    private productService: ProductService) {}

  ngOnInit(): void {
    console.log('ngOnInit called');
    this.productService.getData().subscribe((data) => {
      this.productsCategory = data;
    });
  }

  public addToCart(product: any) {
    if (this.accountService.getLoginStatus()) {
      this.productService.addProduct(product);
      alert(`${product.name} has been added to your cart!`);
    } else {
      // User is not logged in, redirect to account page
      alert('Please log in or sign up to add items to the cart.');
    }
  }
}
