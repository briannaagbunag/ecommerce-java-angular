import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AccountService } from '../service/account.service';
import { Router } from '@angular/router';
import { Customer } from '../model/customer';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  isLoggedIn = false;
  user: Customer | null = null;
  isSignUpMode = true;

  signUpForm: FormGroup;
  loginForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private accountService: AccountService,
    private router: Router
  ) {
    this.signUpForm = this.fb.group({
      firstname: ['', Validators.required],
      middlename: [''],
      lastname: ['', Validators.required],
      dateOfBirth: [
        '',
        [Validators.required, Validators.pattern(/^\d{4}-\d{2}-\d{2}$/)] // YYYY-MM-DD format
      ],
      gender: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
    
  

    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ngOnInit() {
    // Check if the user is logged in by retrieving the value from localStorage
    this.isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    
    if (this.isLoggedIn) {
      // Retrieve the user data from localStorage if available
      const storedUser = localStorage.getItem('user');
      if (storedUser) {
        this.user = JSON.parse(storedUser);
      } else {
        // Fallback to default values if no stored user data is found
        this.user = {
          id: 0,
          firstname: '',
          middlename: '',
          lastname: '',
          dateOfBirth: '',
          gender: '',
          username: '',
          password: ''
        };
      }
    }
  }
  
  

  onSignUp() {
    console.log('Sign up button clicked'); // Check if this logs in the console
    if (this.signUpForm.valid) {
      this.accountService.signUp(this.signUpForm.value).subscribe(
        (response: Customer) => {
          console.log('Sign-up successful:', response);
          alert('Account created successfully!');
          this.isSignUpMode = false; // Switch to login mode after sign-up
          this.signUpForm.reset(); // Clear form after success
        },
        (error) => {
          console.error('Sign-up failed:', error);
          alert('Sign-up failed: ' + error.message);
        }
      );
    } else {
      console.warn('Form is invalid');
    }
  }
  
  

  onLogin() {
    if (this.loginForm.valid) {
      this.accountService.login(this.loginForm.value).subscribe(
        (response: Customer) => {
          alert('Login successful!');
          this.isLoggedIn = true;
          this.user = response;
          this.accountService.setLoginStatus(true);
  
          // Store user data in localStorage
          localStorage.setItem('user', JSON.stringify(this.user));
          localStorage.setItem('isLoggedIn', 'true');
  
          this.router.navigate(['/home']); // Redirect after login if needed
        },
        error => {
          alert('Login failed: ' + error.message);
        }
      );
    }
  }
  

  onLogout() {
    this.accountService.setLoginStatus(false);
    this.isLoggedIn = false;
    this.user = null;
  
    // Clear user data from localStorage
    localStorage.removeItem('user');
    localStorage.removeItem('isLoggedIn');
  }

  toggleMode() {
    this.isSignUpMode = !this.isSignUpMode;
  }
}
