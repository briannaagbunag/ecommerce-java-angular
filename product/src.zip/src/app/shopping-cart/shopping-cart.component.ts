import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product';
import { ProductCategory } from '../model/product-category';
import { ProductService } from '../service/product.service';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css'],
})
export class ShoppingCartComponent implements OnInit {
  loadingStates: { [key: number]: boolean } = {};
  public productsCategory: ProductCategory[] = [];
  errorMessage: string = '';
  selectedProduct: Product | null = null;

  constructor(private productService: ProductService) {}

  cartItems: any[] = [];  

  ngOnInit(): void {
    this.cartItems = this.productService.getProduct();
    };

  public deleteFromCart(product: any): void {
    this.productService.deleteProduct(product);
    this.cartItems = this.productService.getProduct();  // Refresh the cart
  }
}
