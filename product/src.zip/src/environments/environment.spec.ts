import { environment } from './environment';

describe('Environment', () => {
  it('should create an instance', () => {
    expect(new Environment()).toBeTruthy();
  });
});
